const fs = nativeRequire('fs')

const wsClient = require('wsClient.js')

module.exports = {

    init: function() {
        global.remote = new wsClient(/* WEBSOCKET URL GOES HERE*/)
        global.remote.connect()
    },

    oscOutFilter: function(data) {
        
        const { address, args, host, port, clientId } = data;
        
        if (address === '/wsClient') {
            global.remote.sendMessage({
                /**
                 * WS MESSAGE GOES HERE!!!
                 * use the variables above to implement
                 */
            });
        }
        
        return { address, args, host, port };
    },

};