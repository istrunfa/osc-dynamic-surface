const testingInner = () => "fromInner!"

module.exports = {
  testingInner,
}
