const { testingInner } = require("./testInner.js")

const testing = () => {
  testingInner()
}

module.exports = {
  testing,
}
