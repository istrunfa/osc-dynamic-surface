const { _init } = require("./oscFilters/init.js")
const { _oscInFilter } = require("./oscFilters/oscInFilter.js")
const { _oscOutFilter } = require("./oscFilters/oscOutFilter.js")
const { _unload } = require("./oscFilters/unload.js")

// OSC exec order logs
// init -> created -> open -> sessionOpened -> sessionClosed -> close -> destroyed -> unload
app.on("open", () => console.log("open"))
app.on("sessionOpened", () => console.log("sessionOpened"))
app.on("reload", () => console.log("the app has reloaded"))
app.on("close", () => console.log("close"))
app.on("created", () => console.log("created"))
app.on("destroyed", () => console.log("destroyed"))

module.exports = {
  init: () => _init(),
  unload: () => _unload(),
  oscInFilter: (data) => _oscInFilter(data),
  oscOutFilter: (data) => _oscOutFilter(data),
}
