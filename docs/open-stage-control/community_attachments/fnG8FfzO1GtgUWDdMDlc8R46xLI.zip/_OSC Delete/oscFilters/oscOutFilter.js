const { testing } = require("../tests/test.js")

/**
 * Filter outgoing osc messages
 * @param {Data} data
 */
const _oscOutFilter = (data) => {
  testing()
  return data
}

module.exports = {
  _oscOutFilter,
}
