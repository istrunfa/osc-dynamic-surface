/**
 * this will be executed once when the osc server starts
 */
const _init = () => console.log("init")

module.exports = {
  _init,
}
