/**
 * Filter incoming osc messages
 * @param {{address: string, args: any[], host: string, port: number | string, clientId: string}} data
 */
const _oscInFilter = (data) => data

module.exports = {
  _oscInFilter,
}
