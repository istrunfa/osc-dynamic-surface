/**
 * this will be executed when the custom module is reloaded
 */
const _unload = () => console.log("\x1b[43msaved and reloading osc\x1b[0m")

module.exports = {
  _unload,
}
