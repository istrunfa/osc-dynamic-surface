const { sendOscControl } = require('../oscUtils.js');
const { sendOscCommandWithShowAll } = require('../oscUtils.js');


const {
    midiPortShowAll,
    midiPortLibraryShow,
    midiPortLibraryHide,
    midiPortLibraryAdd,
    midiPortLibraryMute,
    midiPortLibrarySolo,
    midiPortLibrarySelect,
    midiPortLibraryName,
    midiPortFolderGet
} = require('../config/midiConfig.js').trackVisibilityMidi;

let {
    midiPortEnsFilter,
    midiPortInstrFilter,
    midiPortSoloInstrFilter
} = require('../config/midiConfig.js').trackVisibilityMidi;
let {
    libraryFilterSwitchVal,
    filterMidiChan,
    filterccValtoSend,
    folderGetVal,
    folderGetMidiChan,
    folderGetccSendVal,
    libraryFilterCase,
    libraryFilterInVal,
    libraryFilterccSendVal,
    libraryFilterMidiChanBase,
    ensFilterInVal,
    ensFilterSwitchVal,
    ensFilterMidiChanRoot,
    ensFilterMidiChan,
    ensFilterccSendVal,
    showOnlySwitch,
    showAllMidiChan,
    showAllccVal,
    instrFilterSwitchVal,
    soloOnlySwitchVal,
    soloInstrOnlySwitch,
    instrFilterInVal,
    instrFilterccSendVal,
    instrFilterMidiChanRoot,
    selectorccValtoSend
} = require('../config/filterModuleConfig.js');

function handleFilterMessage(address, args) {
    address = address.trim(); // Trim white spaces
    console.log(`handleFilterMessage called with address: "${address}", args: ${JSON.stringify(args)}`);

    // Additional logging to trace flow
    console.log(`Comparing address: "${address}"`);

    if (address.startsWith('/LibraryFilterBtn_')) {
        console.log('/LibraryFilterBtn_ condition matched');
        const btnIndex = parseInt(address.substr('/LibraryFilterBtn_'.length));
        handleLibraryFilterBtn(btnIndex, args);
    } else if (address === '/ensFilterBtn') {
        console.log('ensFilterBtn condition true');
        handleEnsembleFilterBtn(args);
    } else if (address === '/InstrFilterBtn') {
        console.log('/InstrFilterBtn condition true');
        handleInstrumentFilterBtn(args);
    } else if (address === '/folderGetBtn') {
        console.log('/folderGetBtn condition true');
        handleFolderGetBtn(args);
    } else if (address === '/soloOnlyFilterSwitch') {
        console.log('/soloOnlyFilterSwitch condition true');
        handleSoloOnlyInstrBtn(args);
    } else if (address === '/instrFilterSwitch') {
        console.log('/instrFilterSwitch condition true');
        handleInstrFilterSwitch(args);
    } else if (address === '/ensFilterSwitch') {
        console.log('/ensFilterSwitch condition true');
        handleEnsFilterSwitch(args);
    } else if (address === '/LibraryFilterSwitch') {
        console.log('/LibraryFilterSwitch condition true');
        handleLibraryFilterSwitch(args);
    } else {
        console.log('No matching condition found for address');
    }

    function handleFolderGetBtn(args) {
        console.log('handleFolderGetBtn called');
        folderGetccSendVal = args[0].value;
        console.log(`Calling sendOscControl with values: ${folderGetccSendVal}, ${folderGetMidiChan}, ${midiPortFolderGet}`);
        sendOscControl(folderGetccSendVal, folderGetMidiChan, midiPortFolderGet);
    }
    function handleSoloOnlyInstrBtn(args) {
        soloInstrOnlySwitch = args[0].value
        console.log("soloInstrOnlySwitch Value updated to = " + soloInstrOnlySwitch)
    }
    function handleInstrFilterSwitch(args) {
        instrFilterSwitchVal = args[0].value
        console.log("instrFilterSwitchVal Value updated to = " + instrFilterSwitchVal)
    }
    function handleEnsFilterSwitch(args) {
        ensFilterSwitchVal = args[0].value
        console.log("ensFilterSwitchVal Value updated to = " + ensFilterSwitchVal)
    }
    function handleLibraryFilterSwitch(args) {
        libraryFilterSwitchVal = args[0].value
        console.log("libraryFilterSwitchVal Value updated to = " + libraryFilterSwitchVal)
    }
    function handleLibraryFilterBtn(btnIndex, args) {
        const BASE_OFFSET = 128;
        libraryFilterInVal = args[0].value;
        libraryFilterccSendVal = libraryFilterInVal - btnIndex * BASE_OFFSET;
        libraryFilterMidiChan = libraryFilterMidiChanBase + btnIndex;

        function sendLibraryFilterCommand(port) {
            console.log(`Calling sendOscControl with values: ${libraryFilterccSendVal}, ${libraryFilterMidiChan}, ${port}`);
            sendOscControl(libraryFilterccSendVal, libraryFilterMidiChan, port);
        }

        switch (libraryFilterSwitchVal) {
            case 1:

                sendOscCommandWithShowAll(libraryFilterccSendVal, libraryFilterMidiChan, midiPortLibraryShow, showAllccVal, showAllMidiChan, midiPortShowAll);
                //sendLibraryFilterCommand(midiPortLibraryShow);
                break;
            case 2:
                sendLibraryFilterCommand(midiPortLibraryHide);
                break;
            case 3:
                sendLibraryFilterCommand(midiPortLibraryAdd);
                break;
            case 4:
                sendLibraryFilterCommand(midiPortLibraryMute);
                break;
            case 5:
                sendLibraryFilterCommand(midiPortLibrarySolo);
                break;
            case 6:
                sendLibraryFilterCommand(midiPortLibrarySelect);
                break;
            case 7:
                sendLibraryFilterCommand(midiPortLibraryName);
                break;
            default:
                console.log("Invalid library filter switch value");
                break;
        }
    }

    function handleEnsembleFilterBtn(args) {
        console.log('handleEnsembleFilterBtn called');
        ensFilterInVal = args[0].value;
        ensFilterccSendVal = ensFilterInVal;
        ensFilterMidiChan = ensFilterMidiChanRoot + ensFilterSwitchVal;

        switch (ensFilterSwitchVal) {
            case 1:
                sendOscCommandWithShowAll(ensFilterccSendVal, ensFilterMidiChan, midiPortEnsFilter, showAllccVal, showAllMidiChan, midiPortShowAll);
                break;
            default:
                console.log(`Calling sendOscControl with values: ${ensFilterccSendVal}, ${ensFilterMidiChan}, ${midiPortEnsFilter}`);
                sendOscControl(ensFilterccSendVal, ensFilterMidiChan, midiPortEnsFilter);
                break;
        }
    }

    function handleInstrumentFilterBtn(args) {
        console.log('handleInstrumentFilterBtn called');
        console.log('soloInstrOnlySwitch Value = ' + soloInstrOnlySwitch)
        console.log('instrFilterSwitchVal Value = ' + instrFilterSwitchVal)
        instrFilterInVal = args[0].value;
        instrFilterccSendVal = instrFilterInVal;
        instrFilterMidiChan = instrFilterMidiChanRoot + instrFilterSwitchVal;


        switch (soloInstrOnlySwitch) {
            case 1:
                midiPortInstrFilter = midiPortInstrFilter;
                break;
            case 2:
                midiPortInstrFilter = midiPortSoloInstrFilter;
                break;
        }

        switch (instrFilterSwitchVal) {
            case 1:
                sendOscCommandWithShowAll(instrFilterccSendVal, instrFilterMidiChan, midiPortInstrFilter, showAllccVal, showAllMidiChan, midiPortShowAll);
                break;
            default:
                console.log(`Calling sendOscControl with values: ${instrFilterccSendVal}, ${instrFilterMidiChan}, ${midiPortInstrFilter}`);
                sendOscControl(instrFilterccSendVal, instrFilterMidiChan, midiPortInstrFilter);
                break;
        }
    }

 
}

module.exports = {
    handleFilterMessage
};
