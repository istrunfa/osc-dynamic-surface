// JavaScript source code
//nudgeModule.js
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Nudge Module
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


const { sendOscControl } = require('../oscUtils.js');

const { nudgeMidiPort } = require('../config/midiConfig.js').nudgeModuleMidi;


let nudgeDirection = 1;
let nudgeSelection = 1;
let nudgeChannel = 1; //keep as nudgeMidiChanForward

let nudgeMidiChanForward = 1;
let nudgeMidiChanBackward = 2;

function handleNudgeMessage(address, args) {


    if (address === '/nudgeDirection') {
        nudgeDirection = args[0].value;

        switch (nudgeDirection) {
            case 1:
                nudgeChannel = nudgeMidiChanForward;
                break;
            case 2:
                nudgeChannel = nudgeMidiChanBackward;
                break;
        }
        console.log(`nudgeChannel set to: ${nudgeChannel}`);
        return;
    }

    if (address === '/nudge') {
        console.log('/Nudge Pressed');
        sendOscControl(nudgeSelection, nudgeChannel, nudgeMidiPort);
        return;
    }

    if (address === '/nudgeSelection') {
        nudgeSelection = args[0].value;

        let new_label = [
            "",
            "Nudge On Grid",
            "Relative Position +-5",
            "Relative Position +-10",
            "Relative Velo <br>& Pos -+ 10%",
            "Randomize pos +-5",
            "Randomize pos +-10",
            "Relative Position -+5",
            "Relative Position -+10",
            "Relative Position -+50",
            "Relative Position -+100",
            "1ms",
            "10ms",
            "100ms",
            "1sec",
            "10secs",
            "1 Frame",
            "10 Frames",
            "100 Frames",
            "1 smpl",
            "10 smpls",
            "100 smpls",
            "1000 smpls",
            "24000 smpls",
            "44100 smpls",
            "48000 smpls",
            "30 PPQ",
            "40 PPQ",
            "60 PPQ -  1/32 Note",
            "120 PPQ - 1/16 Note",
            "240 PPQ - 1/8 Note",
            "480 PPQ - 1/4 Note",
        ];

        receive('/EDIT', 'modal_nudge', { type: 's', value: { 'label': new_label[nudgeSelection] } });
        return;
    }

    if (address === '/nudgeClose') {

        receive('/modal_nudge', 0);
        return;
    }
}

module.exports = {
    handleNudgeMessage
};
