// modules/transposeModule.js

const { sendOscControl } = require('../oscUtils.js');
const transposeConfig = require('../config/transposeConfig.js');
let {
    transposeMidiPort,
} = require('../config/midiConfig.js').transposeModuleMidi;

function handleTransposeMessage(address, args) {
    if (address === '/transDirection') {
        transposeConfig.transDirection = args[0].value;

        const transChannelMap = {
            1: transposeConfig.transMidiChanUp,
            2: transposeConfig.transMidiChanUpCopy,
            3: transposeConfig.transMidiChanUpExtr,
            4: transposeConfig.transMidiChanUpExtrCopy,
            5: transposeConfig.transMidiChanDown,
            6: transposeConfig.transMidiChanDownCopy,
            7: transposeConfig.transMidiChanDownExtr,
            8: transposeConfig.transMidiChanDownExtrCopy
        };

        transposeConfig.transChannel = transChannelMap[transposeConfig.transDirection];
        return;
    }

    if (address === '/transpose') {
        const semiToneMoveMap = {
            1: 0,
            2: 1,
            3: 1,
            4: 2,
            5: 3,
            6: 3,
            7: 4,
            8: 5,
            9: 6,
            10: 6,
            11: 7,
            12: 8,
            13: 8,
            14: 9,
            15: 10,
            16: 10,
            17: 11,
            18: 12
        };

        transposeConfig.semiToneMove = semiToneMoveMap[transposeConfig.transposeInterval];
        sendOscControl(transposeConfig.semiToneMove, transposeConfig.transChannel, transposeMidiPort);
        return;
    }

    if (address === '/transposeInterval') {
        transposeConfig.transposeInterval = args[0].value;

        const labels = [
            " ", "Perfect Unison", "Augmented Unison - 1 Semitone", "minor Second - One Half Step",
            "Major Second - 1 Full Tone", "Augmented Second - 3 Semitones", "Minor Third  - 3 Semitones",
            "Major Third - 4 Semitones", "Perfect Fourth - 5 Semitones", "Tritone - 6 Semitones",
            "Diminished Fifth - 6 Semitones", "Perfect Fifth - 7 Semitones", "Augmented Fifth - 8 Semitones",
            "Minor Sixth - 8 Semitones", "Major Sixth - 9 Semitones", "Augmented Sixth - 10 Semitones",
            "Minor Seventh - 10 Semitones", "Major Seventh - 11 Semitones", "Perfect Octave - 12 Semitones"
        ];

        receive('/EDIT', 'modal_transpose_interval', { type: 's', value: { 'label': labels[transposeConfig.transposeInterval] } });
        receive('/modal_transpose_interval', 0);
        return;
    }
}

module.exports = {
    handleTransposeMessage
};
