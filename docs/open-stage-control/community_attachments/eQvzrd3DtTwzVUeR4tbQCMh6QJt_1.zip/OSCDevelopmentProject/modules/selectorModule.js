const { sendOscControl } = require('../oscUtils.js');

const {
    selectorMidiPortAll,
    selectorMidiPortInCycle,
    selectorMidiPortSelected,
    selectorMidiPortb4Cur,
    selectorMidiPortAfterCur,
} = require('../config/midiConfig.js').selectorModuleMidi;

const {
    selectorMidiChanAll,
    selectorMidiChanInCycle,
    selectorMidiChanSelected,
    selectorMidiChanb4Cur,
    selectorMidiChanAfterCur,
    bumpByCase1,
    bumpByCase2,
    bumpByCase3,
    RhythmTripInd,
    rhythmNthNote,
} = require('../config/selectorModuleConfig.js');

let {
    selectorMidiPort,
} = require('../config/midiConfig.js').selectorModuleMidi;

let {
    selectorMidiChan,
    selectorBeatNote,
    selectorBarRange,
    bumpMidiChan,
    RhythmWholeBeat,
    miscSelectorVal,
    selectorType,
    selectorSubType,
    selectorccValtoSend,
    panelTimeSigVal,
    clefLine
} = require('../config/selectorModuleConfig.js');

// Function to check if variables are undefined or null
function checkVariables(variables) {
    const errors = [];
    for (const [key, value] of Object.entries(variables)) {
        if (value === undefined || value === null) {
            errors.push(`${key} is not populated correctly in Selector Module.`);
        }
    }
    return errors;
}

try {
    // Check if all variables are populated correctly
    const errors = checkVariables({
        selectorMidiPortAll,
        selectorMidiPortInCycle,
        selectorMidiPortSelected,
        selectorMidiPortb4Cur,
        selectorMidiPortAfterCur,
        selectorMidiChan,
        selectorMidiChanAll,
        selectorMidiChanInCycle,
        selectorMidiChanSelected,
        selectorMidiChanb4Cur,
        selectorMidiChanAfterCur,
        selectorBeatNote,
        selectorBarRange,
        bumpMidiChan,
        bumpByCase1,
        bumpByCase2,
        bumpByCase3,
        RhythmTripInd,
        RhythmWholeBeat,
        rhythmNthNote,
        miscSelectorVal,
        selectorType,
        selectorSubType,
        selectorccValtoSend,
        panelTimeSigVal,
        clefLine
    });

    if (errors.length > 0) {
        throw new Error(errors.join('\n'));
    }

    // If the check passes, proceed with the rest of your code
    // Your logic here

} catch (error) {
    // Handle the error appropriately
    // You can add more error handling logic here if needed
}

function handleRhythmSelection() {
    switch (selectorSubType) {
        case 1:
            selectorccValtoSend = miscSelectorVal;
            break;
        case 2:
        case 3:
            handleRhythm(selectorBeatNote, clefLine);
            break;
    }
}

function handleRhythm(beatNote, line) {
    switch (beatNote) {
        case 1: // Whole Beat
            selectorccValtoSend = getRhythmValue(RhythmWholeBeat);
            break;
        case 2: // Individual Note
        case 3: // Every Nth Note
            selectorccValtoSend = getRhythmValue(getRhythmType(line, beatNote));
            break;
    }
}

function getRhythmType(line, beatNote) {
    switch (beatNote) {
        case 2: // Individual Note
            return getIndividualNoteRhythm(line);
        case 3: // Every Nth Note
            return getNthNoteRhythm(line);
    }
}

function getIndividualNoteRhythm(line) {
    switch (line) {
        case 1: return Rhythm1_4Ind;
        case 2: return Rhythm1_4TripInd;
        case 3: return Rhythm1_8Ind;
        case 4: return Rhythm1_8TripInd;
        case 5: return Rhythm1_16Ind;
        case 6: return Rhythm1_16TripInd;
    }
}

function getNthNoteRhythm(line) {
    switch (line) {
        case 1: return RhythmNthNote1_4;
        case 2: return RhythmNthNote1_4Trip;
        case 3: return RhythmNthNote1_8;
        case 4: return RhythmNthNote1_8Trip;
        case 5: return RhythmNthNote1_16;
        case 6: return RhythmNthNote1_16Trip;
    }
}

function getRhythmValue(rhythm) {
    // Add any additional processing or validation here if needed
    return rhythm;
}

function handleSelectorSelect() {
    switch (selectorSubType) {
        case 1:
            bumpMidiChan = bumpByCase1;
            break;
        case 2:
            bumpMidiChan = bumpByCase2;
            break;
        case 3:
            bumpMidiChan = bumpByCase3;
            break;
    }

    switch (selectorBarRange) {
        case 1: // All In Event
            selectorMidiPort = selectorMidiPortAll;
            selectorMidiChan = selectorMidiChanAll + bumpMidiChan;
            handleRhythmSelection();
            break;
        case 2: // Inside Locator Range
            selectorMidiPort = selectorMidiPortInCycle;
            selectorMidiChan = selectorMidiChanInCycle + bumpMidiChan;
            handleRhythmSelection();
            break;
        case 3: // All Selected Notes
            selectorMidiPort = selectorMidiPortSelected;
            selectorMidiChan = selectorMidiChanSelected + bumpMidiChan;
            handleRhythmSelection();
            break;
        case 4: // Before Cursor
            selectorMidiPort = selectorMidiPortb4Cur;
            selectorMidiChan = selectorMidiChanb4Cur + bumpMidiChan;
            handleRhythmSelection();
            break;
        case 5: // After Cursor
            selectorMidiPort = selectorMidiPortAfterCur;
            selectorMidiChan = selectorMidiChanAfterCur + bumpMidiChan;
            handleRhythmSelection();
            break;
        case 6: // Not Used
            break;
    }

    sendOscControl(selectorccValtoSend, selectorMidiChan, selectorMidiPort);
}

function handleSelectorMessage(address, args) {
    if (address === '/selector_selectNote') {
        handleSelectorSelect();
    }
    const addressToVariableMap = {
        '/panel_TimeSig': () => { panelTimeSigVal = args[0].value; },
        '/noteSelector_subtype': () => { selectorSubType = args[0].value; },
        '/switch_rhythm3': () => { selectorccValtoSend = args[0].value; },
        '/noteSwitchBeatNote': () => { selectorBeatNote = args[0].value; },
        '/noteSelectorBarRange': () => { selectorBarRange = args[0].value; },
        '/noteSwitch_RhythmWholeBeat': () => { RhythmWholeBeat = args[0].value; },
        '/noteSwitch_RhythmNthNote1_4': () => { RhythmNthNote1_4 = args[0].value; },
        '/noteSwitch_Rhythm1_4Ind': () => { Rhythm1_4Ind = args[0].value; },
        '/noteSwitch_RhythmNthNote1_4Trip': () => { RhythmNthNote1_4Trip = args[0].value; },
        '/noteSwitch_Rhythm1_4TripInd': () => { Rhythm1_4TripInd = args[0].value; },
        '/noteSwitch_RhythmNthNote1_8': () => { RhythmNthNote1_8 = args[0].value; },
        '/noteSwitch_Rhythm1_8Ind': () => { Rhythm1_8Ind = args[0].value; },
        '/noteSwitch_RhythmNthNote1_8Trip': () => { RhythmNthNote1_8Trip = args[0].value; },
        '/noteSwitch_Rhythm1_8TripInd': () => { Rhythm1_8TripInd = args[0].value; },
        '/noteSwitch_RhythmNthNote1_16': () => { RhythmNthNote1_16 = args[0].value; },
        '/noteSwitch_Rhythm1_16Ind': () => { Rhythm1_16Ind = args[0].value; },
        '/noteSwitch_RhythmNthNote1_16Trip': () => { RhythmNthNote1_16Trip = args[0].value; },
        '/noteSwitch_Rhythm1_16TripInd': () => { Rhythm1_16TripInd = args[0].value; },
        '/noteSwitch_miscSelector': () => { miscSelectorVal = args[0].value; },
        '/noteSwitch_Clef': () => { clefLine = args[0].value; },
    };

    // Check if the address is in the map, then execute the corresponding function
    const handlerFunction = addressToVariableMap[address];
    if (handlerFunction) {
        handlerFunction();
    }
}

module.exports = {
    handleSelectorMessage
};
