// JavaScript source code
//These are the address variabes for the panels that
//show the quick Controls
//Probably defunct soon as will be a MIDI Remote in Cubase
//But May be reperposed

// VST QUICK CONTROLS VARIABLES
const QCTagsOnOff = {
    'QC1': '/QC1/show', 'QC2': '/QC2/show', 'QC3': '/QC3/show', 'QC4': '/QC4/show', 'QC5': '/QC5/show',
    'QC6': '/QC6/show', 'QC7': '/QC7/show', 'QC8': '/QC8/show', 'QC9': '/QC9/show', 'QC10': '/QC10/show'
};

const QCLabels = {
    'QC1': '/QC1/label', 'QC2': '/QC2/label', 'QC3': '/QC3/label', 'QC4': '/QC4/label', 'QC5': '/QC5/label',
    'QC6': '/QC6/label', 'QC7': '/QC7/label', 'QC8': '/QC8/label', 'QC9': '/QC9/label', 'QC10': '/QC10/label'
};

const qcCCValues = {
    'qcFader1': '/qcFader1/qcVal',
    'qcFader2': '/qcFader2/qcVal',
    'qcFader3': '/qcFader3/qcVal',
    'qcFader4': '/qcFader4/qcVal',
    'qcFader5': '/qcFader5/qcVal',
    'qcFader6': '/qcFader6/qcVal',
    'qcFader7': '/qcFader7/qcVal',
    'qcFader8': '/qcFader8/qcVal',
};

// VST TRACK QUICK CONTROLS VARIABLES
const TQCTagsOnOff = {
    'TQC1': '/TQC1/show', 'TQC2': '/TQC2/show', 'TQC3': '/TQC3/show', 'TQC4': '/TQC4/show', 'TQC5': '/TQC5/show',
    'TQC6': '/TQC6/show', 'TQC7': '/TQC7/show', 'TQC8': '/TQC8/show', 'TQC9': '/TQC9/show', 'TQC10': '/TQC10/show'
};

const TQCLabels = {
    'TQC1': '/TQC1/label', 'TQC2': '/TQC2/label', 'TQC3': '/TQC3/label', 'TQC4': '/TQC4/label', 'TQC5': '/TQC5/label',
    'TQC6': '/TQC6/label', 'TQC7': '/TQC7/label', 'TQC8': '/TQC8/label', 'TQC9': '/TQC9/label', 'TQC10': '/TQC10/label'
};

const TQCCCValues = {
    'tqcFader1': '/tqcFader1/tqcVal',
    'tqcFader2': '/tqcFader2/tqcVal',
    'tqcFader3': '/tqcFader3/tqcVal',
    'tqcFader4': '/tqcFader4/tqcVal',
    'tqcFader5': '/tqcFader5/tqcVal',
    'tqcFader6': '/tqcFader6/tqcVal',
    'tqcFader7': '/tqcFader7/tqcVal',
    'tqcFader8': '/tqcFader8/tqcVal',
};

module.exports =  { QCTagsOnOff, QCLabels, qcCCValues, TQCTagsOnOff, TQCLabels, TQCCCValues };

