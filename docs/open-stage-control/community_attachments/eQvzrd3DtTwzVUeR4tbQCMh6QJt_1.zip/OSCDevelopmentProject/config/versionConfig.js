
//Open Stage control config File for Measured Effort Cubase Control Panel
//config.js

// Custom Module Information
const customModuleName = "Measured Effort Cubase Control";
const cmVerNo = "3.0";
const customModuleVer = `${customModuleName} ${cmVerNo}`;



module.exports = {
    customModule: {
        name: "Measured Effort Cubase Control",
        version: "3.0",
        fullVersion: `Measured Effort Cubase Control 3.0`
    }
};
