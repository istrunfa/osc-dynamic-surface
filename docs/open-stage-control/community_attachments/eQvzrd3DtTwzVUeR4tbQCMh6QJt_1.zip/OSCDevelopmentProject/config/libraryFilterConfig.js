// JavaScript source code
//Variables for Library Filter Module


module.exports = {

    showAll: {
        MidiChan: 1,
        ccVal: 51
    },

    soloOnly: {
        SwitchVal: 1,
        Switch: 1
    },

    libraryFilter: {
        Case: 0,
        FilterInVal: 0,
        ccSendVal: 1000,
        SwitchVal: 100,
        MidiChanBase: 1
    },

    ensFilter: {
        InVal: 0,
        SwithchVal: 0,  // Correct the typo here if it's meant to be 'SwitchVal'
        MidiChanRoot: 0,
        MidiChan: 0,
        ccSendVal: 0
    },

    instrFilter: {
        InVal: 0,
        SendVal: 0,
        MidiChanRoot: 0,
        SwitchVal: 0
    },

    // Variables for Folder Navigation Buttons
    folderGet: {
        Val: 1,
        MidiChan: 5,
        ccSendVal: 1
    },
};
