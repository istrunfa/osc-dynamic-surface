const NOTES_TO_ACTIONS = {
    // VPOT ASSIGN
    40: 'assign_track',
    41: 'assign_send',
    42: 'assign_pan',
    43: 'assign_plugin',
    44: 'assign_eq',
    45: 'assign_instrument',

    // FADER BANKS
    46: 'bank_left',
    47: 'bank_right',
    48: 'bank_channel_left',
    49: 'bank_channel_right',
    50: 'bank_flip',
    51: 'bank_global',

    // DISPLAY
    52: 'display_name_value',
    53: 'display_smpte_beats',

    // FUNCTION SELECT
    54: 'f1',
    55: 'f2',
    56: 'f3',
    57: 'f4',
    58: 'f5',
    59: 'f6',
    60: 'f7',
    61: 'f8',

    // GLOBAL VIEW
    62: 'view_midi_tracks',
    63: 'view_inputs',
    64: 'view_audio_tracks',
    65: 'view_audio_instruments',
    66: 'view_aux',
    67: 'view_busses',
    68: 'view_outputs',
    69: 'view_user',

    // MODIFIERS
    70: 'mod_shift',
    71: 'mod_option',
    72: 'mod_control',
    73: 'mod_alt',

    // AUTOMATION
    74: 'automation_read',
    75: 'automation_write',
    76: 'automation_trim',
    77: 'automation_touch',
    78: 'automation_latch',
    79: 'automation_group',

    // UTILITIES
    80: 'save',
    81: 'undo',
    82: 'cancel',
    83: 'enter',

    // MISC
    84: 'markers',
    85: 'nudge',
    86: 'cycle',
    87: 'drop',
    88: 'replace',
    89: 'click',
    90: 'global_solo',

    // TRANSPORT
    91: 'rewind',
    92: 'forward',
    93: 'stop',
    94: 'play',
    95: 'record',
    96: 'up',
    97: 'down',
    98: 'left',
    99: 'right',
    100: 'zoom',
    101: 'scrub',

    // LEDS
    113: 'led_smpte',
    114: 'led_beats',
    115: 'led_solo'
};

const ACTIONS_TO_NOTES = Object.fromEntries(
    Object.entries(NOTES_TO_ACTIONS).map(([k, v]) => [v, parseInt(k)])
);

module.exports = { NOTES_TO_ACTIONS, ACTIONS_TO_NOTES };
