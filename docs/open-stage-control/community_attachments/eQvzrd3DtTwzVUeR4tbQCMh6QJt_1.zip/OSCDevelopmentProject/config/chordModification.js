// JavaScript source code
//chordModification.js

// modules/chordModification.js
module.exports = chordModification = {
    transposeFromValue: 1,
    transposeToValue: 1,
    chordType: "Select the chordstructure to move from and to - - Mofification will appear here",
};
