// JavaScript source code
//config/selectorModuleConfig.js
// Configuration for Selector Module
module.exports = {

    selectorMidiChan: 0,
    selectorMidiChanAll: 0,
    selectorMidiChanInCycle: 1,
    selectorMidiChanSelected: 2,
    selectorMidiChanb4Cur: 3,
    selectorMidiChanAfterCur: 4,

    selectorBeatNote: 1,
    selectorBarRange:1,

    bumpMidiChan: 0,
    bumpByCase1: 1,
    bumpByCase2: 6,
    bumpByCase3: 12,

    RhythmTripInd: 20,
    RhythmWholeBeat : 1,
    rhythmNthNote : 10,
    miscSelectorVal: 0,

    selectorType: 1,
    selectorSubType: 2,
    selectorccValtoSend: 1,
    panelTimeSigVal: 1,
    clefLine: 1



};


//RhythmTripInd: 20, // set to 20 to allow flexibility of other selectors
 //   RhythmWholeBeat : 1, // set to 1 as alwasy the default position