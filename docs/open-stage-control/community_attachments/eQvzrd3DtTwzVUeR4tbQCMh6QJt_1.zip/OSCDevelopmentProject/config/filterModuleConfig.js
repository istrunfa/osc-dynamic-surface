// JavaScript source code
//filterModuleConfig.js

module.exports = {

    libraryFilterSwitchVal : 100,
    filterMidiChan : 1,
    filterccValtoSend: 1,
    folderGetVal : 1,
    folderGetMidiChan : 5,
    folderGetccSendVal : 1,
     libraryFilterCase : 0,
    libraryFilterInVal : 0,
     libraryFilterccSendVal : 1000,
     libraryFilterMidiChanBase : 1,
    ensFilterInVal : 0,
    ensFilterSwitchVal : 0,
    ensFilterMidiChanRoot : 0,
    ensFilterMidiChan : 15,
    ensFilterccSendVal : 0,
    showOnlySwitch : 1,
    showAllMidiChan : 1,
    showAllccVal : 51,
    instrFilterSwitchVal : 1,
    soloOnlySwitchVal : 1,
    soloInstrOnlySwitch : 1,
    instrFilterInVal :0,
    instrFilterccSendVal : 0,
    instrFilterMidiChanRoot : 0,
    selectorccValtoSend : 1

}
