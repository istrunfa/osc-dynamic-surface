// JavaScript source code
//These are the vairables that are used in the articulations functions

module.exports = {
    artButtons: {
        'b1': '/b1/show', 'b2': '/b2/show', 'b3': '/b3/show', 'b4': '/b4/show', 'b5': '/b5/show',
        'b6': '/b6/show', 'b7': '/b7/show', 'b8': '/b8/show', 'b9': '/b9/show', 'b10': '/b10/show',
        'b11': '/b11/show', 'b12': '/b12/show', 'b13': '/b13/show', 'b14': '/b14/show', 'b15': '/b15/show',
        'b16': '/b16/show', 'b17': '/b17/show', 'b18': '/b18/show', 'b19': '/b19/show', 'b20': '/b20/show',
        'b21': '/b21/show', 'b22': '/b22/show', 'b23': '/b23/show', 'b24': '/b24/show', 'b25': '/b25/show',
        'b26': '/b26/show', 'b27': '/b27/show', 'b28': '/b28/show', 'b29': '/b29/show', 'b30': '/b30/show',
        'b31': '/b31/show', 'b32': '/b32/show', 'b33': '/b33/show', 'b34': '/b34/show', 'b35': '/b35/show',
        'b36': '/b36/show', 'b37': '/b37/show', 'b38': '/b38/show', 'b39': '/b39/show', 'b40': '/b40/show',
        'b41': '/b41/show', 'b42': '/b42/show', 'b43': '/b43/show', 'b44': '/b44/show', 'b45': '/b45/show',
        'b46': '/b46/show', 'b47': '/b47/show', 'b48': '/b48/show', 'b49': '/b49/show', 'b50': '/b50/show',
        'b51': '/b51/show', 'b52': '/b52/show', 'b53': '/b53/show', 'b54': '/b54/show', 'b55': '/b55/show',
        'b56': '/b56/show', 'b57': '/b57/show', 'b58': '/b58/show', 'b59': '/b59/show', 'b60': '/b60/show'
    },
    artLabels: {
        'b1': '/b1/label', 'b2': '/b2/label', 'b3': '/b3/label', 'b4': '/b4/label', 'b5': '/b5/label',
        'b6': '/b6/label', 'b7': '/b7/label', 'b8': '/b8/label', 'b9': '/b9/label', 'b10': '/b10/label',
        'b11': '/b11/label', 'b12': '/b12/label', 'b13': '/b13/label', 'b14': '/b14/label', 'b15': '/b15/label',
        'b16': '/b16/label', 'b17': '/b17/label', 'b18': '/b18/label', 'b19': '/b19/label', 'b20': '/b20/label',
        'b21': '/b21/label', 'b22': '/b22/label', 'b23': '/b23/label', 'b24': '/b24/label', 'b25': '/b25/label',
        'b26': '/b26/label', 'b27': '/b27/label', 'b28': '/b28/label', 'b29': '/b29/label', 'b30': '/b30/label',
        'b31': '/b31/label', 'b32': '/b32/label', 'b33': '/b33/label', 'b34': '/b34/label', 'b35': '/b35/label',
        'b36': '/b36/label', 'b37': '/b37/label', 'b38': '/b38/label', 'b39': '/b39/label', 'b40': '/b40/label',
        'b41': '/b41/label', 'b42': '/b42/label', 'b43': '/b43/label', 'b44': '/b44/label', 'b45': '/b45/label',
        'b46': '/b46/label', 'b47': '/b47/label', 'b48': '/b48/label', 'b49': '/b49/label', 'b50': '/b50/label',
        'b51': '/b51/label', 'b52': '/b52/label', 'b53': '/b53/label', 'b54': '/b54/label', 'b55': '/b55/label',
        'b56': '/b56/label', 'b57': '/b57/label', 'b58': '/b58/label', 'b59': '/b59/label', 'b60': '/b60/label'
    },
    classType: {
        'b1': '/b1/classType', 'b2': '/b2/classType', 'b3': '/b3/classType', 'b4': '/b4/classType', 'b5': '/b5/classType',
        'b6': '/b6/classType', 'b7': '/b7/classType', 'b8': '/b8/classType', 'b9': '/b9/classType', 'b10': '/b10/classType',
        'b11': '/b11/classType', 'b12': '/b12/classType', 'b13': '/b13/classType', 'b14': '/b14/classType', 'b15': '/b15/classType',
        'b16': '/b16/classType', 'b17': '/b17/classType', 'b18': '/b18/classType', 'b19': '/b19/classType', 'b20': '/b20/classType',
        'b21': '/b21/classType', 'b22': '/b22/classType', 'b23': '/b23/classType', 'b24': '/b24/classType', 'b25': '/b25/classType',
        'b26': '/b26/classType', 'b27': '/b27/classType', 'b28': '/b28/classType', 'b29': '/b29/classType', 'b30': '/b30/classType',
        'b31': '/b31/classType', 'b32': '/b32/classType', 'b33': '/b33/classType', 'b34': '/b34/classType', 'b35': '/b35/classType',
        'b36': '/b36/classType', 'b37': '/b37/classType', 'b38': '/b38/classType', 'b39': '/b39/classType', 'b40': '/b40/classType',
        'b41': '/b41/classType', 'b42': '/b42/classType', 'b43': '/b43/classType', 'b44': '/b44/classType', 'b45': '/b45/classType',
        'b46': '/b46/classType', 'b47': '/b47/classType', 'b48': '/b48/classType', 'b49': '/b49/classType', 'b50': '/b50/classType',
        'b51': '/b51/classType', 'b52': '/b52/classType', 'b53': '/b53/classType', 'b54': '/b54/classType', 'b55': '/b55/classType',
        'b56': '/b56/classType', 'b57': '/b57/classType', 'b58': '/b58/classType', 'b59': '/b59/classType', 'b60': '/b60/classType'
    }
};
