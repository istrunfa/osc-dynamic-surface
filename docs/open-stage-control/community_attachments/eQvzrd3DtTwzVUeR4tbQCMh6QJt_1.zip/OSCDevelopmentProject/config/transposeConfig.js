// config/transposeConfig.js

module.exports = {
    transDirection: 0,
    transMidiChanUp: 1,
    transMidiChanUpCopy: 2,
    transMidiChanUpExtr: 3,
    transMidiChanUpExtrCopy: 4,
    transMidiChanDown: 5,
    transMidiChanDownCopy: 6,
    transMidiChanDownExtr: 7,
    transMidiChanDownExtrCopy: 8,
    transChannel: 0,
    semiToneMove: 0,
    transposeInterval: 0,
    transposeMidiPort: 'defaultMidiPort', // Replace with actual default MIDI port value
};
