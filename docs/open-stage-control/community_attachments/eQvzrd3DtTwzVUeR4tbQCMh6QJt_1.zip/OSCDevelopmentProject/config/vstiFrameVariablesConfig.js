// JavaScript source code
// This contains all the variables that are used to show and hide vstiFrames in the functions as follows:
// Check earlier versions of primary file to see what the variables are


// JavaScript source code


const ccVSTiFader = Object.fromEntries(
    Array.from({ length: 80 }, (_, i) => [`ccVSTi_${i + 1}`, `ccFaderVSTi${i + 1}`])
);

const vstiFrames = Object.fromEntries(
    Array.from({ length: 47 }, (_, i) => [`VSTiFrame${i}`, `/VstiFrame${i}/vstiView`])
);

const ccVSTiLabels = Object.fromEntries(
    Array.from({ length: 128 }, (_, i) => [`ccLabelVSTi${i + 1}`, `/ccLabelVSTi${i + 1}/VSTiLabel`])
);

const ccVSTiLabShow = Object.fromEntries(
    Array.from({ length: 128 }, (_, i) => [`ccLabelVSTi${i + 1}`, `/ccLabelVSTi${i + 1}/VSTiShow`])
);

const ccVSTiccValues = Object.fromEntries(
    Array.from({ length: 128 }, (_, i) => [`ccFaderVSTi${i + 1}`, `/ccFaderVSTi${i + 1}/ccVal`])
);

module.exports = { ccVSTiFader, vstiFrames, ccVSTiLabels, ccVSTiLabShow, ccVSTiccValues };
