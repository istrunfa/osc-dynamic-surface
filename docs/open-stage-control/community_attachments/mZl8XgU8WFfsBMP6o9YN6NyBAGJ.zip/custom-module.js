// LOAD JSON FILES
var vepArticulations = loadJSON('../data/filemaker/vepArticulations.json')
var vepInstruments = loadJSON('../data/filemaker/vepInstruments.json')
var vepKeys = loadJSON('../data/filemaker/vepKeys.json')

// SET VARIABLE WIDGET
app.on('sessionOpened', (data, client)=>{
	receive('/variable_vepKeys', vepKeys)
})


var CCfaderCC19 = ""
var CCfaderCC21 = ""
var CCfaderCC22 = ""
var CCfaderCC23 = ""
var CCfaderCC24 = ""

module.exports = {

	init: function(){
		// this will be executed once when the osc server starts
	},
	
    oscInFilter:function(data){
        var {address, args, host, port} = data

		// Um die Faderbewegung vom fadermaster von CC7 im OSC Anzeigen zu lassen /////////////////////////////////////////////////////////////////
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 11) {
			receive('/EDIT', 'cFad1', {value: args[2].value})
		}
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 1) {
			receive('/EDIT', 'cFad2', {value: args[2].value})
		}
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 10) {
			receive('/EDIT', 'cFad13', {value: args[2].value})
		}
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 7) {
			receive('/EDIT', 'cFad14', {value: args[2].value})
		}
		// Um die Faderbewegung vom fadermaster von CC7 im OSC Anzeigen zu lassen /////////////////////////////////////////////////////////////////



		if (host === 'midi' && port === 'HUI' && address === '/sysex') {

			
			// FILTER OUT UNWANTED SYSEX

			if (args[0].value.includes('f0 00 00 66 05 00 10')) return {address, args, host, port}
			if (args[0].value.includes('f0 00 00 66 05 00 11')) return {address, args, host, port}
			if (args[0].value.includes('f0 00 00 66 05 00 12 04 20 45 51 20 31 20 47 61 69 6e 05 20 45 51 20 31 20 46 72 65 71 06 20 20 45 51 20 31 20 51 20 20 07 20 20 45 51 20 31 20 4f 6e 20 f7')) return {address, args, host, port}
			if (args[0].value.includes('f0 00 00 66 05 00 12 04 20 20 20 20 20 20 20 20 20 20 05 20 20 20 20 20 20 20 20 20 20 06 20 20 20 20 20 20 20 20 20 20 07 20 20 20 20 20 20 20 20 20 20 f7')) return {address, args, host, port}
			
			
			// CUBASE TRACKS HEX TO ASCII STRING

			var input  = args[0].value.split(' ').splice(9 ,5);
			//var remove = input.splice(9, 1);
			input.pop();			
			input = input.join('');
			var trackname = '';
			for (var n = 0; n < input.length; n += 2) {
				trackname += String.fromCharCode(parseInt(input.substr(n, 2), 16));
			}

			// ***************** Rename Button with Instrument name *******************************/

			var codeFromCubase = parseInt (trackname);
			if (codeFromCubase >= 0 && codeFromCubase <= 5000){
				var instrName = (vepInstruments.instrument [codeFromCubase]['instrumentName'])
				var groupName = (vepInstruments.instrument [codeFromCubase]['group'])
				var prodName = (vepInstruments.instrument [codeFromCubase]['productName'])
				var prodNote = (vepInstruments.instrument [codeFromCubase]['productNote'])

				// ****************** Visible or Unvisible Faders for Microphones *************************/

				for (i = 1; i < 15; i++){
					if (vepInstruments.instrument [codeFromCubase]['m'+i] > 0) {
						receive('/EDIT', 'panel_mic_fader' + i, {visible: true}), //visible true
						receive('/EDIT', 'mBez' + i, {value: vepInstruments.instrument [codeFromCubase]['mName' + i]}), // Value
						receive('/EDIT', 'mFad' + i, {preArgs: [1,parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])]}),
						receive('/EDIT', 'mCC' + i, {value: parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])})
					}
					else {
						receive('/EDIT', 'panel_mic_fader' + i, {visible: false}) //visible false
					}
				}

				// ****************** Visible or Unvisible Faders for Controllers *************************/
				
				for (i = 1; i < 15; i++){
					if (vepInstruments.instrument [codeFromCubase]['c'+i] > 0) {
						receive('/EDIT', 'panel_cc_fader' + i, {visible: true}), //visible true
						receive('/EDIT', 'cBez' + i, {value: vepInstruments.instrument [codeFromCubase]['cName' + i]}), // Value
						receive('/EDIT', 'cFad' + i, {preArgs: [1, parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])]}),
						receive('/EDIT', 'cCC' + i, {value: parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])})
					}
					else {
						receive('/EDIT', 'panel_cc_fader' + i, {visible: false}) //visible false
					}

					// Fadermaster controls Reverb CC19, CC21, mic CC22, mic CC23, mic CC24, does not matter where position is ------------------------
					if (parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])==19) {
						CCfaderCC19 = 'cFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])==21) {
						CCfaderCC21 = 'cFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])==22) {
						CCfaderCC22 = 'mFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])==23) {
						CCfaderCC23 = 'mFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])==24) {
						CCfaderCC24 = 'mFad' + i
					}
					// Fadermaster controls Reverb CC19, CC21, mic CC22, mic CC23, mic CC24, does not matter where position is ------------------------

				}

				//***************** D Y N A M I C  A R T I C U L A T I O N  B U T T O N S *****************/
				var artName = ''
				for (i = 1; i < 61; i++){
					var artName = (vepArticulations.articulation [codeFromCubase]['b' + i])
					if (artName.length > 0) {
						receive('/EDIT', 'b' + i, {visible: true}),
						receive('/EDIT', 'b' + i, {label: vepArticulations.articulation [codeFromCubase]['b' + i]})
					}
					else {
						receive('/EDIT', 'b' + i, {visible: false}),
						receive('/EDIT', 'b' + i, {label: ''})
					}
					//console.log("hilfe_*********************************************************");
					//console.log(artName)
				}
				//***************** D Y N A M I C  A R T I C U L A T I O N  B U T T O N S *****************/

			}
			else {
				var instrName = 'Nicht in der Datenbank';
				var groupName = '(eigener)';
				var prodName = 'Cubase eintrag';
				var codeFromCubase = 0;

				// Hide Mic Faders
				for (i = 1; i < 15; i++){
					if (vepInstruments.instrument [codeFromCubase]['m'+i] > 0) {
						receive('/EDIT', 'panel_mic_fader' + i, {visible: true}), //visible true
						receive('/EDIT', 'mBez' + i, {value: vepInstruments.instrument [codeFromCubase]['mName' + i]}), // Value
						receive('/EDIT', 'mFad' + i, {preArgs: [1,parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])]}),
						receive('/EDIT', 'mCC' + i, {value: parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])})
					}
					else {
						receive('/EDIT', 'panel_mic_fader' + i, {visible: false}) //visible false
					}
				}
				
				// Hide CC Faders
				for (i = 1; i < 15; i++){
					if (vepInstruments.instrument [codeFromCubase]['c'+i] > 0) {
						receive('/EDIT', 'panel_cc_fader' + i, {visible: true}), //visible true
						receive('/EDIT', 'cBez' + i, {value: vepInstruments.instrument [codeFromCubase]['cName' + i]}), // Value
						receive('/EDIT', 'cFad' + i, {preArgs: [1, parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])]}),
						receive('/EDIT', 'cCC' + i, {value: parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])})
					}
					else {
						receive('/EDIT', 'panel_cc_fader' + i, {visible: false}) //visible false
					}

					// Fadermaster controls Reverb CC19, CC21, mic CC22, mic CC23, mic CC24, does not matter where position is ------------------------
					if (parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])==19) {
						CCfaderCC19 = 'cFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['c' + i])==21) {
						CCfaderCC21 = 'cFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])==22) {
						CCfaderCC22 = 'mFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])==23) {
						CCfaderCC23 = 'mFad' + i
					}
					if (parseInt(vepInstruments.instrument [codeFromCubase]['m' + i])==24) {
						CCfaderCC24 = 'mFad' + i
					}
					// Fadermaster controls Reverb CC19, CC21, mic CC22, mic CC23, mic CC24, does not matter where position is ------------------------

				}

				// Hide ART Buttons
				for (i = 1; i < 61; i++){
					receive('/EDIT', 'b' + i, {visible: false}),
					receive('/EDIT', 'b' + i, {label: ''})
				}
			}
			
			var keyStart = parseInt(vepInstruments.instrument [codeFromCubase]['keyRangeStart'])
			var keyStartKey = vepInstruments.instrument [codeFromCubase]['keyRangeStartKey']
			var keyEnd = parseInt(vepInstruments.instrument [codeFromCubase]['keyRangeEnd'])
			var keyEndKey = vepInstruments.instrument [codeFromCubase]['keyRangeEndKey']
			var venGrpName = prodName +" "+ groupName
			receive('/EDIT', 'text_code', {value: trackname}),
			receive('/EDIT', 'text_instrument', {value: instrName}),
			receive('/EDIT', 'text_vendor', {value: venGrpName}),
			receive('/EDIT', 'text_productNote', {value: prodNote}),
			receive('/EDIT', 'range_2A_art_keyboard', {value: [keyStart, keyEnd + 1]}),
			receive('/EDIT', 'text_2A_art_range_key_start', {value: keyStartKey}),
			receive('/EDIT', 'text_2A_art_range_key_end', {value: keyEndKey})
		
			// Add Special Buttons
			for (i = 1; i < 13; i++){
				if (vepInstruments.instrument [codeFromCubase]['s'+i] > 0) {
					
					
					var specialkeyAndName = "(" + vepInstruments.instrument [codeFromCubase]['sKey' + i] +")\n"+ vepInstruments.instrument [codeFromCubase]['sName' + i]
					receive('/EDIT', 's' + i, {visible: true}), //visible true
					receive('/EDIT', 's' + i, {label: specialkeyAndName}), // Value
					receive('/EDIT', 's' + i, {preArgs: [1,parseInt(vepInstruments.instrument [codeFromCubase]['s' + i])]})
				}
				else {
					receive('/EDIT', 's' + i, {visible: false}) //visible false
				}
			}
			// Add Special Buttons
		

		
		}
		
		// My Fadermaster control Reverb CC19, CC21, CC22, CC23, CC24, egal wo die Position ist -------------------------------------
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 19) {
			receive('/EDIT', CCfaderCC19, {value: args[2].value})
		}
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 21) {
			receive('/EDIT', CCfaderCC21, {value: args[2].value})
		}
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 22) {
			receive('/EDIT', CCfaderCC22, {value: args[2].value})
		}
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 23) {
			receive('/EDIT', CCfaderCC23, {value: args[2].value})
		}
		if (host === 'midi' && port === 'MLP2' && address === '/control' && args[0].value === 1 && args[1].value === 24) {
			receive('/EDIT', CCfaderCC24, {value: args[2].value})
		}
		// My Fadermaster control Reverb CC19, CC21, CC22, CC23, CC24, egal wo die Position ist -------------------------------------

		// Beats and Bars with the MCU Midi Port
		if (data.host === 'midi' && data.port === 'MCU') {
            
            var [channel, control, value] = data.args.map(x=>x.value)

            if (control > 63 && control < 74) {
                
                var digit = 73 - control,
                    msb = value >> 4,
                    val = value & 0xF
                
                if (msb >> 2) val += '.'
                if (!(msb & (1 << 1))) val = ''

                // digit -> digit
                // val -> digit's value 
                // assuming 10 text widgets with incrementing preArgs 
                receive('/timecode', digit, val)

                return
                
            }
        }
		// Beats and Bars with the MCU Midi Port


		return {address, args, host, port}
    },

	oscOutFilter:function(data){
		// Filter outgoing osc messages

        var {address, args, host, port, clientId} = data

        // same as oscInFilter

        // return data if you want the message to be and sent
        return {address, args, host, port}
	},

	unload:function(){
		// this will be executed when the custom module is reloaded
	}
}	
